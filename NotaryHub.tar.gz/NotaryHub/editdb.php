<?php
session_start();
$user=$_SESSION['userprofile'];


$username = "root";
$password = "";
$dbname = "project";
$con = new mysqli("localhost",$username,$password,$dbname);
$sql = "Update userdata  SET fname='$_POST[fname]',lname='$_POST[lname]',email='$_POST[email]',password='$_POST[password]',Phone_Number='$_POST[phone]' where fname ='$user'";

$con->query($sql);
$_SESSION['userprofile']=$_POST[fname];
header("location:user.php");

?> 
