

 <?php
if (isset($_POST["register"])) {
$user = $_POST["name"];
$mail = $_POST["email"];
$pass = $_POST["password"];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";

// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO userdata (username, email, password)
VALUES ('$user', '$mail', '$pass')";

$conn->query($sql);
 
echo"successful";


$conn->close();
}
?> 
