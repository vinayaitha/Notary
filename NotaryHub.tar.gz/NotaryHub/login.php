<?php

$error=''; // Variable To Store Error Message
if(isset($_POST['submit'])) {
	if (empty($_POST['email']) || empty($_POST['password'])) {
$error = "Username or Password is invalid";
}
else
{
   include("connectdb.php");
	
$username=$_POST['email'];
$password=$_POST['password'];
$sql ="SELECT fname FROM userdata WHERE email='$username' AND password='$password'";
$result=$conn->query($sql);
if ($result->num_rows > 0) {
	
	while($row=$result->fetch_assoc()){
		$user= $row["fname"];
	}
$_SESSION['login_user']=$user;
$_SESSION['loggedin_time']=time();// Initializing Session
header("location:DashBoard.php"); // Redirecting To Other Page
} else {
 echo "<script type='text/javascript'> alert('username or password Invalid ') </script>";
}

}
}
?>
